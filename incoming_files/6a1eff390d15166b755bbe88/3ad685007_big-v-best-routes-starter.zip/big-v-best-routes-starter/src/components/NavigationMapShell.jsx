import { Navigation, TriangleAlert, Volume2 } from 'lucide-react';

export default function NavigationMapShell({ navigation, vehicle }) {
  return (
    <section className="navShell">
      <div className="fakeMap3d">
        <div className="mapSkyline" />
        <svg className="routeSvg" viewBox="0 0 420 680" preserveAspectRatio="none" aria-hidden="true">
          <path d="M210 670 C190 560 270 520 245 430 C220 330 140 310 178 215 C212 130 300 116 286 20" className="routeShadow" />
          <path d="M210 670 C190 560 270 520 245 430 C220 330 140 310 178 215 C212 130 300 116 286 20" className="routeLine" />
        </svg>
        <div className="vehicleMarker"><Navigation size={30} /></div>
        <div className="restrictionPin"><TriangleAlert size={20} /> Low bridge</div>
        <div className="mapBadge topLeft">3D Map-ready shell</div>
        <div className="mapBadge topRight">GPS {navigation.gpsConfidence || 0}%</div>
      </div>

      <div className="navInstructionCard">
        <div>
          <p className="eyebrow">Navigation PWA</p>
          <h2>{navigation.currentInstruction}</h2>
          <p>Vehicle locked during active navigation: <strong>{vehicle.name}</strong></p>
        </div>
        <div className="navActions">
          <button className="ghost"><Volume2 size={18} /> Voice</button>
          <button className="ghost">Reroute</button>
          <button className="dangerButton">Stop</button>
        </div>
      </div>
    </section>
  );
}
