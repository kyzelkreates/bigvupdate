import NavigationMapShell from '../components/NavigationMapShell.jsx';

export default function NavigationPWA({ state, setState }) {
  const activeVehicle = state.vehicle.profiles[state.vehicle.activeVehicleId];
  const isActive = state.navigation.active;

  function startNavigation() {
    setState((draft) => {
      draft.navigation.active = true;
      draft.navigation.lockedVehicleId = draft.vehicle.activeVehicleId;
      draft.navigation.gpsConfidence = 88;
      draft.navigation.currentInstruction = 'Follow the highlighted route. Prepare for next instruction.';
      draft.app.mode = 'navigation';
    });
  }

  function stopNavigation() {
    setState((draft) => {
      draft.navigation.active = false;
      draft.navigation.lockedVehicleId = null;
      draft.navigation.currentInstruction = 'Navigation stopped. Vehicle profile can now be changed.';
    });
  }

  return (
    <main className="navigationPage">
      <NavigationMapShell navigation={state.navigation} vehicle={activeVehicle} />
      <div className="navControlBar">
        {!isActive ? <button className="primary" onClick={startNavigation}>Start navigation and lock vehicle</button> : <button className="dangerButton" onClick={stopNavigation}>Stop navigation</button>}
        <span className="badge">Offline fallback shell ready</span>
        <span className="badge purple">Route polyline + 3D map-ready</span>
      </div>
    </main>
  );
}
