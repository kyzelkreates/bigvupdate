import VehicleForm from '../components/VehicleForm.jsx';
import CompliancePanel from '../components/CompliancePanel.jsx';

export default function PlannerDashboard({ state, setState, runCompliance, calculateRoute }) {
  const activeVehicle = state.vehicle.profiles[state.vehicle.activeVehicleId];

  function updateVehicleType(type) {
    setState((draft) => {
      const vehicle = draft.vehicle.profiles[draft.vehicle.activeVehicleId];
      vehicle.type = type;
      vehicle.fields = {};
    });
  }

  function updateVehicleField(field, value) {
    setState((draft) => {
      draft.vehicle.profiles[draft.vehicle.activeVehicleId].fields[field] = value;
    });
  }

  return (
    <main className="pageGrid">
      <section className="heroPanel">
        <p className="eyebrow">Driver Trip Planning Dashboard</p>
        <h1>Plan, check, and validate a route before navigation starts.</h1>
        <p>GraphHopper-ready routing with Big V’s advisory Compliance AI, modular vehicle input, legal-critical warnings, and offline-first PWA foundations.</p>
        <div className="heroActions">
          <button className="primary" onClick={calculateRoute}>Calculate via GraphHopper</button>
          <button className="ghost" onClick={runCompliance}>Run Compliance AI</button>
        </div>
      </section>

      <section className="panel tripPanel">
        <div className="panelHeader"><div><p className="eyebrow">Trip</p><h2>Journey details</h2></div></div>
        <label className="field"><span>Origin</span><input value={state.trip.origin} onChange={(e) => setState((draft) => { draft.trip.origin = e.target.value; })} /></label>
        <label className="field"><span>Destination</span><input value={state.trip.destination} onChange={(e) => setState((draft) => { draft.trip.destination = e.target.value; })} /></label>
        <p className="disclaimer">GraphHopper adapter is isolated in src/core/graphHopperAdapter.js so Base44 can safely wire keys/geocoding without touching UI logic.</p>
      </section>

      <VehicleForm vehicle={activeVehicle} onChangeType={updateVehicleType} onChangeField={updateVehicleField} />
      <CompliancePanel compliance={state.compliance} onRunCheck={runCompliance} />
    </main>
  );
}
