import { useMemo, useState } from 'react';
import { Map, Route, ShieldCheck, Settings, Smartphone } from 'lucide-react';
import PlannerDashboard from './pages/PlannerDashboard.jsx';
import NavigationPWA from './pages/NavigationPWA.jsx';
import { loadState, resetState, updateState } from './core/storage.js';
import { runComplianceCheck } from './core/complianceEngine.js';
import { calculateGraphHopperRoute } from './core/graphHopperAdapter.js';
import './styles/app.css';

export default function App() {
  const [state, setRawState] = useState(loadState);
  const activeVehicle = state.vehicle.profiles[state.vehicle.activeVehicleId];

  function setState(recipe) {
    setRawState((current) => updateState(current, recipe));
  }

  function runCompliance() {
    setState((draft) => {
      const vehicle = draft.vehicle.profiles[draft.vehicle.activeVehicleId];
      draft.compliance = runComplianceCheck({ vehicle, trip: draft.trip, restrictions: draft.restrictions });
    });
  }

  async function calculateRoute() {
    const result = await calculateGraphHopperRoute({
      origin: state.trip.origin,
      destination: state.trip.destination,
      vehicle: activeVehicle,
      apiKey: state.settings.graphHopperApiKey,
    });
    setState((draft) => {
      draft.compliance.warnings = [
        { id: 'graphhopper-result', level: result.ok ? 'info' : 'warning', title: 'GraphHopper adapter', detail: result.message },
        ...draft.compliance.warnings.filter((w) => w.id !== 'graphhopper-result'),
      ];
    });
  }

  const view = useMemo(() => state.app.mode, [state.app.mode]);

  return (
    <div className="appShell">
      <aside className="sidebar">
        <div className="brandBlock">
          <div className="brandIcon">BV</div>
          <div>
            <strong>Big V’s Best Routes</strong>
            <span>Safety-first navigation OS</span>
          </div>
        </div>
        <nav>
          <button className={view === 'planner' ? 'active' : ''} onClick={() => setState((draft) => { draft.app.mode = 'planner'; })}><Route size={18} /> Trip planning</button>
          <button className={view === 'navigation' ? 'active' : ''} onClick={() => setState((draft) => { draft.app.mode = 'navigation'; })}><Map size={18} /> Navigation PWA</button>
          <button onClick={runCompliance}><ShieldCheck size={18} /> Compliance AI</button>
          <button><Smartphone size={18} /> Installable PWA</button>
          <button><Settings size={18} /> Settings</button>
        </nav>
        <div className="sideCard">
          <span>Active vehicle</span>
          <strong>{activeVehicle.name}</strong>
          <small>{activeVehicle.type.toUpperCase()} template</small>
        </div>
        <button className="resetButton" onClick={() => setRawState(resetState())}>Reset demo state</button>
      </aside>

      <section className="content">
        <header className="topBar">
          <div>
            <p className="eyebrow">Created for Kyzel Kreates build flow</p>
            <h1>{view === 'planner' ? 'Driver dashboard' : '3D navigation dashboard shell'}</h1>
          </div>
          <div className="topBadges">
            <span className="badge green">GraphHopper-ready</span>
            <span className="badge purple">Compliance AI</span>
            <span className="badge">Local-first SSOT</span>
          </div>
        </header>

        {view === 'planner' ? (
          <PlannerDashboard state={state} setState={setState} runCompliance={runCompliance} calculateRoute={calculateRoute} />
        ) : (
          <NavigationPWA state={state} setState={setState} />
        )}
      </section>
    </div>
  );
}
