export async function calculateGraphHopperRoute({ origin, destination, vehicle, apiKey }) {
  if (!apiKey) {
    return {
      ok: false,
      provider: 'graphhopper',
      message: 'GraphHopper API key not configured. Add it in Settings before live routing.',
      route: null,
    };
  }

  // Base44/finish-off note:
  // Replace geocoding placeholders with real origin/destination coordinates.
  // GraphHopper routing endpoint expects point=lat,lon pairs.
  // Keep provider logic isolated here. Do not put API calls inside UI components.
  const vehicleProfile = mapVehicleToGraphHopperProfile(vehicle?.type);
  return {
    ok: false,
    provider: 'graphhopper',
    message: `GraphHopper adapter ready for ${vehicleProfile}. Wire geocoding + API key in Base44 production step.`,
    route: null,
  };
}

export function mapVehicleToGraphHopperProfile(type) {
  const map = {
    car: 'car',
    van: 'car',
    hgv: 'truck',
    motorhome: 'truck',
    trailer: 'truck',
    bus: 'truck',
    motorcycle: 'motorcycle',
    bicycle: 'bike',
    custom: 'truck',
  };
  return map[type] || 'car';
}
