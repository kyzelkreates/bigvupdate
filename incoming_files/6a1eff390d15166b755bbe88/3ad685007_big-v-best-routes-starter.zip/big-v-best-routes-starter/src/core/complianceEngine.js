import { fieldDefinitions, vehicleTemplates } from '../config/vehicleTemplates.js';

export function runComplianceCheck({ vehicle, trip, restrictions }) {
  const warnings = [];
  const evidence = [];
  const template = vehicleTemplates[vehicle?.type];
  let score = 100;

  if (!vehicle) {
    return fail('No active vehicle selected', 'Choose a vehicle before planning a route.');
  }
  if (!template) {
    return fail('Unknown vehicle type', 'Vehicle type has no legal field template.');
  }

  for (const fieldKey of template.fields) {
    const field = fieldDefinitions[fieldKey];
    const value = vehicle.fields?.[fieldKey];
    if (field?.required && (value === undefined || value === null || value === '')) {
      warnings.push({ id: `missing-${fieldKey}`, level: field.legalCritical ? 'danger' : 'warning', title: `Missing ${field.label}`, detail: field.helper });
      score -= field.legalCritical ? 12 : 6;
    }
  }

  if (!trip?.origin || !trip?.destination) {
    warnings.push({ id: 'trip-missing', level: 'warning', title: 'Trip origin or destination missing', detail: 'Add both before route calculation.' });
    score -= 10;
  }

  const roadCount = restrictions?.roadRestrictions?.length || 0;
  const bridgeCount = restrictions?.bridgeRestrictions?.length || 0;
  evidence.push({ label: 'Vehicle template checked', value: template.label });
  evidence.push({ label: 'Road restrictions loaded', value: String(roadCount) });
  evidence.push({ label: 'Bridge restrictions loaded', value: String(bridgeCount) });

  if (roadCount + bridgeCount === 0) {
    warnings.push({ id: 'no-restriction-data', level: 'warning', title: 'No restriction data imported', detail: 'Import bridge and road restriction CSVs before relying on route suitability.' });
    score -= 18;
  }

  const status = score >= 85 ? 'appears_suitable' : score >= 60 ? 'needs_review' : 'high_risk';
  warnings.push({ id: 'legal-disclaimer', level: 'info', title: 'Advisory only', detail: 'Road signs, local restrictions, police instructions, and driver judgement override app guidance.' });

  return { status, score: Math.max(0, Math.min(100, score)), warnings, evidence, dataFreshness: roadCount + bridgeCount > 0 ? 'local-imported-data' : 'sample-data' };
}

function fail(title, detail) {
  return { status: 'blocked', score: 0, warnings: [{ id: 'blocked', level: 'danger', title, detail }], evidence: [], dataFreshness: 'unknown' };
}
